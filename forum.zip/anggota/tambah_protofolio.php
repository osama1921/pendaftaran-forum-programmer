<div class="content" style="margin-top:0;">
				<form class="content-form" action="proses_portofolio.php" method="POST">
				<label>Bidang Keahlian</label>
				<input type="text" name="bidang" placeholder="Bidang Keahlian..." class="content-form-text">
				<label>Riwayat Pelatihan</label>
				<textarea placeholder="Pelatihan pernah anda ikuti" class="content-form-text" name="riwayat"></textarea>
				<label>Sertifikat</label>
				<textarea placeholder="Sertifikat yang di miliki ..." class="content-form-text" name="sertifikat"></textarea>
				<label>Project</label>
				<textarea placeholder="Project yang pernah di miliki ..." class="content-form-text" name="project"></textarea>
				<input type="submit" name="tambah" class="content-form-submit" value="Tambah Portofolio">
			</form>
			<br>
				<br>
		</div>