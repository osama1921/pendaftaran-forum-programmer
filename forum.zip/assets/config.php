<?php 
$kon=mysqli_connect('localhost', 'root','');
mysqli_select_db($kon, 'forum');
?>